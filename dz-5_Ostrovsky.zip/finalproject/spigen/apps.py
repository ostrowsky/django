from django.apps import AppConfig


class SpigenConfig(AppConfig):
    name = 'spigen'
