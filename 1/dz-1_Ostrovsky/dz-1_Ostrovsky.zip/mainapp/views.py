from django.shortcuts import render, render_to_response
def main(request):
    return render(request, 'index.html')

def work(request):
    return render(request, 'work.html')

def education(request):
    return render(request, 'education.html')

# Create your views here.
