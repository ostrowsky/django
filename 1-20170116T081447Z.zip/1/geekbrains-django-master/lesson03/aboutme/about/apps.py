from django.apps import AppConfig


class AboutConfig(AppConfig):
    name = 'about'
