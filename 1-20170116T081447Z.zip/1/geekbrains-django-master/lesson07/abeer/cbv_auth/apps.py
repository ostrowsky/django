from django.apps import AppConfig


class CbvAuthConfig(AppConfig):
    name = 'cbv_auth'
