address = "Москва, Большое Очаковское шоссе д.10"
print(address.encode())
