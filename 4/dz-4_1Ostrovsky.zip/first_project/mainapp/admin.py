from django.contrib import admin
from .models import *

admin.site.register(Work)

admin.site.register(Education)

admin.site.register(Hobby)

admin.site.register(Person)
# Register your models here.
